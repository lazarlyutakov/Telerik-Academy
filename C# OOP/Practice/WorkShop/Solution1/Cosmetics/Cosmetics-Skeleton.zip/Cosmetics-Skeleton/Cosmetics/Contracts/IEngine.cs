﻿using Cosmetics.Products;

namespace Cosmetics.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
