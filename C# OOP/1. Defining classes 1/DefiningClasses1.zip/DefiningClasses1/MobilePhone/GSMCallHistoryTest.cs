﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobilePhone
{
    class GSMCallHistoryTest
    {

        // Uncomment the lower code and comment the "static void Main()" method in class GSM to test !

        //static void Main()
        //{
        //    GSM mobPhone = new GSM("Dragon", "Benefon", 50, "Some guy", new Battery(50, 5, BatteryType.LiIon), new Display(2, 2));
        //    Call call = new Call(DateTime.Now.ToString("dd/MMM/yyyy"), DateTime.Now.ToString("HH:mm:ss "), "0888123456", 120);
        //    mobPhone.AddCalls(call);
        //    call = new Call(DateTime.Now.ToString("dd/MMM/yyyy"), DateTime.Now.ToString("HH:mm:ss "), "098741258", 150);
        //    mobPhone.AddCalls(call);
        //    call = new Call(DateTime.Now.ToString("dd/MMM/yyyy"), DateTime.Now.ToString("HH:mm:ss "), "0888987456", 90);
        //    mobPhone.AddCalls(call);

        //    foreach (var item in mobPhone.callHistory)
        //    {
        //        Console.WriteLine("Call date: {0}, Call Time {1} Phone Number: {2}, Duration: {3}", item.Date, item.Time,
        //                                                                          item.DialedPhoneNumber, item.Duratation);
        //        Console.WriteLine(".".PadRight(100, '.'));

        //    }

        //    Console.WriteLine("Amount to pay : " + mobPhone.CalculatePrice());

        //    uint maxTime = 0;
        //    Call maxDurat = new Call();

        //    foreach (var item in mobPhone.callHistory)
        //    {
        //        if (item.Duratation > maxTime)
        //        {
        //            maxTime = item.Duratation;
        //            maxDurat = item;
        //        }
        //    }

        //    mobPhone.DeleteCalls(maxDurat);

        //    Console.WriteLine("Amount to pay / longest call removed ( {0} sec ) / : " + mobPhone.CalculatePrice(), maxDurat.Duratation);

        //    mobPhone.ClearCalls();

        //    foreach (var item in mobPhone.callHistory)
        //    {
        //        Console.WriteLine("Call date: {0}, Call Time {1} Phone Number: {2}, Duration: {3}", item.Date, item.Time,
        //                                                                          item.DialedPhoneNumber, item.Duratation);

        //    }

        //}

    }
}
