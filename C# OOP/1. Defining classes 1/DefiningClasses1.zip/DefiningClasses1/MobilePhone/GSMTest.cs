﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobilePhone
{
    class GSMTest
    {



        // Comment "static void Main()" method in class GSM and uncomment the lower lines to print the List !


        // static void Main()
        //{
        //    GSM samsung = new GSM("S7", "Samsung", 1200, "Ivan", new Battery(120, 62, BatteryType.LiIon), new Display(5.1f, 16000000000));
        //    GSM sonyXperiaZ5 = new GSM("Xperia Z5", "Sony", 500, "Georgi", new Battery(100, 13, BatteryType.LiIon), new Display(5.2f, 16000000000));
        //    GSM nokiaLumia1020 = new GSM("Lumia 1020", "Nokia", 100, "Dimitar", new Battery(80, 19, BatteryType.LiIon), new Display(4.5f, 16000000000));

        //    List<GSM> gsmList = new List<GSM>();

        //    gsmList.Add(samsung);
        //    gsmList.Add(sonyXperiaZ5);
        //    gsmList.Add(sonyXperiaZ5);



        //foreach (var gsm in gsmList)
        //{
        //    Console.WriteLine(gsm);
        //}

        //Console.WriteLine(GSM.Iphone4S);
        // }







    }
}
