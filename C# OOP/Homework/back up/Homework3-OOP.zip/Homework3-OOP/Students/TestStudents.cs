﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    class TestStudents
    {
        static void Main()
        {
            StudentsNames stt = new StudentsNames();
            stt.ArrangeByNames();
           ;
        }
    }
}




//var listOfStudents = new[]
//            {
//              new {firstName = "Ivan", surname = "Draganov"},
//              new {firstName = "Peter", surname ="Ivanov"},
//              new {firstName = "Gosho", surname ="Todorov"},
//              new {firstName = "Petkan", surname = "Tomov"},
//              new {firstName = "Dragan", surname = "Georgiev"},
//              new {firstName = "Nane", surname = "Vutov"}
//            };