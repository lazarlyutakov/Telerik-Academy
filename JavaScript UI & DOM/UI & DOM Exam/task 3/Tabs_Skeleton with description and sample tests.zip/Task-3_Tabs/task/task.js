function solve() {
	return 'Your template';
}

if(typeof module !== 'undefined') {
	module.exports = solve;
}
